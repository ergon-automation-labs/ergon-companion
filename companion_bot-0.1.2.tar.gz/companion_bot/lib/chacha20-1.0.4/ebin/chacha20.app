{application,chacha20,
             [{config_mtime,1785415557},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"Chacha20 symmetric stream cipher\n"},
              {modules,['Elixir.Chacha20']},
              {registered,[]},
              {vsn,"1.0.4"}]}.
